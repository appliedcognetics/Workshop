import azure.functions as func
import logging
import json
from faker import Faker


app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="datatrigger")
def datatrigger(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )


@app.route(route="mock/customer_product", methods=["GET", "POST"])
def mock_http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    mock_customer_data= {
        "id": fake.uuid4(),
        "first_name": fake.first_name(),
        "last_name": fake.last_name(),
        "address": fake.address(),
        "email": fake.email(),
        "phone_number": fake.phone_number(),
        "job": fake.job(),
        "company": fake.company(),
        "date_of_birth": fake.date_of_birth().isoformat()
    }

    mock_order_data = {
        "order_id": fake.uuid4(),
        "customer_id": mock_customer_data["id"],
         # mock_customer_data["id"],
        "product": fake.catch_phrase(),
        "quantity": fake.random_int(min=1, max=10),
        "price": fake.random_number(digits=5),
        "order_date": fake.date_time_this_year().isoformat()
    }

    # concatenate the two dictionaries
    mock_data = {
        "customer": mock_customer_data,
        "order": mock_order_data
    }

    return func.HttpResponse(
            body=json.dumps(mock_data),
            mimetype="application/json",
            status_code=200
        )

# API Name: GetRestaurantAvailability   
# Input Parameters: location: [lat, long], cuisine (optional): [string], desiredDateTime: [dateTime], numGuests: [int]   
# Expected Output: 30 fake restaurants with ratings (5 star system), address, contact details, and available times within 3 hours of requested time 

@app.route(route="mock/restaurant_availability", methods=["GET", "POST"])
def mock_restaurant_availability(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock data generation
    mock_restaurants = []
    for _ in range(30):
        restaurant = {
            "resturant_id": fake.uuid4(),
            "name": fake.company(),
            "rating": fake.random_int(min=1, max=5),
            "address": fake.address(),
            "contact_number": fake.phone_number(),
            "available_times": [fake.date_time_this_year().isoformat() for _ in range(5)]
        }
        mock_restaurants.append(restaurant)

    return func.HttpResponse(
            body=json.dumps(mock_restaurants),
            mimetype="application/json",
            status_code=200
        )

# API Name: reserveTable 
# Input Parameters: restaurantId: [uuid], desiredDateTime: [dateTime], numGuests: [int] 
# Expected output: confirmation of reservation and any other details 
@app.route(route="mock/reserve_table", methods=["GET", "POST"])
def mock_reserve_table(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock reservation confirmation
    reservation_confirmation = {
        "reservation_id": fake.uuid4(),
        "restaurant_name": fake.company(),
        "reservation_time": fake.date_time_this_year().isoformat(),
        "num_guests": fake.random_int(min=1, max=10),
        "confirmation_message": "Your table has been successfully reserved!"
    }

    return func.HttpResponse(
            body=json.dumps(reservation_confirmation),
            mimetype="application/json",
            status_code=200
        )


# API Name: GetServicesAvailability 
# Input Parameters: location: [lat, long], cuisine (optional): [string], desiredDateTime: [dateTime], numGuests: [int], serviceType (optional): [string]   
# Expected output: A collection of availabilities for services for industries such as beauty spas, nail salons, massage, etc. Should return ratings etc. 
@app.route(route="mock/services_availability", methods=["GET", "POST"])
def mock_services_availability(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock data generation
    mock_services = []
    for _ in range(10):
        service = {
            "service_id": fake.uuid4(),
            "name": fake.company(),
            "rating": fake.random_int(min=1, max=5),
            "address": fake.address(),
            "contact_number": fake.phone_number(),
            "available_times": [fake.date_time_this_year().isoformat() for _ in range(5)]
        }
        mock_services.append(service)

    return func.HttpResponse(
            body=json.dumps(mock_services),
            mimetype="application/json",
            status_code=200
        )

# API Name: bookService 
# Input Parameters: serviceId: [uuid], desiredDateTime: [dateTime], numGuests: [int] 
# Expected output: confirmation of booking and any other details 
@app.route(route="mock/book_service", methods=["GET", "POST"])
def mock_book_service(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock booking confirmation
    booking_confirmation = {
        "booking_id": fake.uuid4(),
        "service_name": fake.company(),
        "booking_time": fake.date_time_this_year().isoformat(),
        "num_guests": fake.random_int(min=1, max=10),
        "confirmation_message": "Your service has been successfully booked!"
    }

    return func.HttpResponse(
            body=json.dumps(booking_confirmation),
            mimetype="application/json",
            status_code=200
        )


# API Name: SearchRecipes 
#  Input Parameters: 
# •	ingredients: string[] (e.g., ["tomato", "pasta"]) 
# •	diet: string (optional, e.g., "vegan", "gluten-free") 
# •	cuisine: string (optional, e.g., "Italian", "Mexican") 
# •	maxTime: number (optional, e.g., 30 for 30 minutes) 
# Expected Output: 
# {   
#   "recipes": [   
#     {   
#       "recipeId": "REC123",   
#       "title": "Tomato Pasta",   
#       "ingredients": ["tomato", "pasta", "olive oil", "garlic"],   
#       "steps": [   
#         "Boil the pasta.",   
#         "Make a sauce using tomatoes, olive oil, and garlic.",   
#         "Combine pasta and sauce."   
#       ],   
#       "prepTime": 20,   
#       "diet": "vegan",   
#       "cuisine": "Italian"   
#     }   
#   ]   
# }   
  
@app.route(route="mock/search_recipes", methods=["GET"])
def mock_search_recipes(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock data generation
    mock_recipes = []
    for _ in range(50):
        recipe = {
            "recipeId": fake.uuid4(),
            "title": fake.catch_phrase(),
            "ingredients": [fake.word() for _ in range(5)],
            "steps": [fake.sentence() for _ in range(3)],
            "prepTime": fake.random_int(min=10, max=60),
            "diet": fake.word(),
            "cuisine": fake.word()
        }
        mock_recipes.append(recipe)

    return func.HttpResponse(
            body=json.dumps({"recipes": mock_recipes}),
            mimetype="application/json",
            status_code=200
        )

# API Name: RetrieveInventory 
#  Input Parameters: 
#  (No input required — this tool simply returns the inventory.) 
  
# Expected Output: 
#  A complete list of all ingredients currently available in the kitchen, along with their quantities and units. 
# {   
#   "inventory": [   
#     { "ingredient": "eggs", "quantity": 8, "unit": "pieces" },   
#     { "ingredient": "milk", "quantity": 1, "unit": "liter" },   
#     { "ingredient": "flour", "quantity": 500, "unit": "grams" }   
#   ]   
# }   
  
@app.route(route="mock/retrieve_inventory", methods=["GET"])
def mock_retrieve_inventory(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock inventory data generation
    mock_inventory = []
    for _ in range(10):
        ingredient = {
            "ingredient": fake.word(),
            "quantity": fake.random_int(min=1, max=100),
            "unit": fake.word()
        }
        mock_inventory.append(ingredient)

    return func.HttpResponse(
            body=json.dumps({"inventory": mock_inventory}),
            mimetype="application/json",
            status_code=200
        )



# API Name: SchedulePropertyTour 
# Input Parameters: prospectId: string, propertyId: string, preferredTime: datetime 
# Expected Output:{"tourId": "tour_010", "status": "scheduled"} 
# Example data: tour  
# o	tourId: string 
# o	prospectId: string 
# o	propertyId: string 
# o	scheduledTime: datetime 
# o	propertyName: string
# o prospectName: string
# o	status: string 

@app.route(route="mock/schedule_property_tour", methods=["GET", "POST"])
def mock_schedule_property_tour(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock property tour scheduling
    tour = {
        "tourId": fake.uuid4(),
        "propertyName": fake.company(),
        "prospectId": fake.uuid4(),
        "prospectName": fake.name(),
        "propertyId": fake.uuid4(),
        "scheduledTime": fake.date_time_this_year().isoformat(),
        "status": "scheduled"
    }

    return func.HttpResponse(
            body=json.dumps(tour),
            mimetype="application/json",
            status_code=200
        )

# 1.	API Name: CreateRequest  
# API Input Parameters { description: string, location: string, contact: string, preferred_time: date, priority: int) API Expected Output { "status": "Request Received" "request_id": "123456"} Expected a table with column request_id | description | location | contact | preferred_time | created_date 
@app.route(route="mock/create_request", methods=["GET", "POST"])
def mock_create_request(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock request creation
    request_data = {
        "request_id": fake.uuid4(),
        "description": fake.sentence(),
        "location": fake.address(),
        "contact": fake.name(),
        "preferred_time": fake.date_time_this_year().isoformat(),
        "priority": fake.random_int(min=1, max=5),
        "created_date": fake.date_time_this_year().isoformat()
    }

    return func.HttpResponse(
            body=json.dumps({"status": "Request Received", **request_data}),
            mimetype="application/json",
            status_code=200
        )

# 2.	API Name: GetRequestByHighestPriority   
# API Expected Output { "description": "Door is broken" "Request Id": "123456", "location": "living room", "contact": "123-123-123", "preferred time": "05/09/2025", "priority": "3"} Expected to mock some fake request in db with different priority, and retrieve next request by highest priority number and oldest created date  
@app.route(route="mock/get_request_by_highest_priority", methods=["GET"])
def mock_get_request_by_highest_priority(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock request data
    mock_requests = []
    for _ in range(10):
        request_data = {
            "request_id": fake.uuid4(),
            "description": fake.sentence(),
            "location": fake.address(),
            "contact": fake.phone_number(),
            "preferred_time": fake.date_time_this_year().isoformat(),
            "priority": fake.random_int(min=1, max=5),
            "created_date": fake.date_time_this_year().isoformat()
        }
        mock_requests.append(request_data)

    # Sort by highest priority and oldest created date
    sorted_requests = sorted(mock_requests, key=lambda x: (-x["priority"], x["created_date"]))

    return func.HttpResponse(
            body=json.dumps(sorted_requests[0]),
            mimetype="application/json",
            status_code=200
        )

# 3.	API Name: CreateTicket  
# API Input Parameters { "Request Id": string } API Expected Output { "status": "active" "Request Id": "123456", "Ticket Id": "MAN1234"} Expected a table with column ticket_id | request_id | status | created_date 
@app.route(route="mock/create_ticket", methods=["GET"])
def mock_create_ticket(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock ticket creation
    ticket_data = {
        "ticket_id": fake.uuid4(),
        "request_id": req.params.get('request_id', fake.uuid4()),
        "status": "active",
        "created_date": fake.date_time_this_year().isoformat()
    }

    return func.HttpResponse(
            body=json.dumps(ticket_data),
            mimetype="application/json",
            status_code=200
        )

## Ian Kinney Try using the bing news
### https://learn.microsoft.com/en-us/azure/ai-services/agents/how-to/tools/bing-grounding?tabs=python&pivots=overview#setup

# API Name: GetSlackMessages    
  
# Input Parameters: None    
# Expected Output: Unread Slack messages with sender information 
  
# Tables:   
# - SlackMessage(sender: string, message: string)   
#   Sample Row: ("john.doe", "Please review the latest documentation") 
@app.route(route="mock/get_slack_messages", methods=["GET"])
def mock_get_slack_messages(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock Slack messages
    mock_messages = []
    for _ in range(10):
        message = {
            "sender": fake.user_name(),
            "message": fake.sentence()
        }
        mock_messages.append(message)

    return func.HttpResponse(
            body=json.dumps(mock_messages),
            mimetype="application/json",
            status_code=200
        )

# API Name: GetUnreadEmails    
# Input Parameters: None    
# Expected Output: Unread emails with subject and sender information 
  
# Tables:   
# - Email(subject: string, sender: string)   
#   Sample Row: ("Meeting reminder for tomorrow", "manager@company.com") 
@app.route(route="mock/get_unread_emails", methods=["GET"])
def mock_get_unread_emails(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock unread emails
    mock_emails = []
    for _ in range(10):
        email = {
            "subject": fake.sentence(),
            "sender": fake.email()
        }
        mock_emails.append(email)

    return func.HttpResponse(
            body=json.dumps(mock_emails),
            mimetype="application/json",
            status_code=200
        ) 

# API Name: GetTodoTasks    
# Input Parameters: None    
# Expected Output: Pending tasks with descriptions and deadlines 
# Tables:   
# - ToDo(task: string, deadline: string)   
#   Sample Row: ("Complete quarterly report", "2025-05-15") 
@app.route(route="mock/get_todo_tasks", methods=["GET"])
def mock_get_todo_tasks(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    fake = Faker()

    # Mock todo tasks
    mock_tasks = []
    for _ in range(10):
        task = {
            "task": fake.sentence(),
            "deadline": fake.date_time_this_year().isoformat()
        }
        mock_tasks.append(task)

    return func.HttpResponse(
            body=json.dumps(mock_tasks),
            mimetype="application/json",
            status_code=200
        )
